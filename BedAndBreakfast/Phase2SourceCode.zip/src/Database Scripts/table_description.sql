SPOOL 'C:\Users\Kevin\Desktop\workspace\CMIS 495\database\database_description.txt' replace

DESC TABLE hotels;
DESC TABLE rooms;
DESC TABLE employees;
DESC TABLE guests;
DESC TABLE reservations;
DESC TABLE addresses;